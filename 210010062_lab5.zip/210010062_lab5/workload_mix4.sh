#!/bin/sh
./arithoh.sh & #CPU intensive
./syscall.sh & #Faster
./arithoh.sh & #CPU intensive
./syscall.sh & #Faster
./arithoh.sh & #CPU intensive
wait