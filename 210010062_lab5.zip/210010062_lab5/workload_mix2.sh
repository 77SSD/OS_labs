#!/bin/sh
./syscall.sh & #Faster
./syscall.sh & #Faster
./syscall.sh & #Faster
./syscall.sh & #Faster
./syscall.sh & #Faster

wait