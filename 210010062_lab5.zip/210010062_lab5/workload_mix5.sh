#!/bin/sh
./arithoh.sh & #CPU intensive
./syscall.sh & #Faster
./fstime.sh  & 
./syscall.sh & #Faster
./fstime.sh  & 
wait