#!/bin/sh
time ../pgms/syscall
echo "syscall completed"
echo "---"
